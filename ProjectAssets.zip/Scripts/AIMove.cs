using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AIMove : MonoBehaviour
{
    public GameObject choice;
    public GameObject States;
    public GameObject[] choices;
    
    void AIStarting()
    {
        //algorithm for choosing State
        GameObject State = States.GetComponent<Transform>().GetChild(0).gameObject;
        Instantiate(choice, State.GetComponent<Transform>().position, new Quaternion(0, 0, 0, 0));
    }

    public List<string> getChoices(GameObject currState)
    {
        //add up, down, left, right to choices array
        //convert state name to string
        string currName = currState.name;
        Debug.Log("current name: " + currName);
        Debug.Log("int space 2: " + currState.name[1]);
        Debug.Log("int name: " + int.Parse(currState.name[1].ToString()));

        int left = int.Parse(currState.name[1].ToString()) - 1;
        int right = int.Parse(currState.name[1].ToString()) + 1;
        int up = int.Parse(currState.name[0].ToString()) - 1;
        int down = int.Parse(currState.name[0].ToString()) + 1;

        Debug.Log("Left State1: " + left);
        string leftS = currName[0].ToString() + left.ToString();
        string rightS = currName[0].ToString() + right.ToString();
        string upS = up.ToString() + currName[1].ToString();
        string downS = down.ToString() + currName[1].ToString();
        Debug.Log("Left State: " + leftS);
        string[] positions = new string[] { leftS, rightS, upS, downS };

        int[] actions = { left, right, up, down };
        for (int i = 0; i < 4; i++)
        {
            if (actions[i] > 4 || actions[i] < 0)
            {
                positions[i] = positions[i].Replace(positions[i], "");
            }
        }
        Debug.Log("Position: " + positions[0]);
        List<string> possibleMoves = new List<string>();
        
        for(int i = 0;i<4;i++)
        {
            if(positions[i].Contains('0'))
            {
                continue;
            }
            else
            {
                possibleMoves.Add(positions[i]);
            }
        }
        for(int i = 0;i< possibleMoves.Count;i++)
        {
            Debug.Log("possibleMoves: " + possibleMoves[i]);
        }

        return possibleMoves;
    }

    IEnumerator game()
    {
        GameObject State = States.GetComponent<Transform>().GetChild(0).gameObject;
        Instantiate(choice, State.GetComponent<Transform>().position, new Quaternion(0, 0, 0, 0));
        yield return new WaitForSeconds(2);
        GameObject State1 = States.GetComponent<Transform>().GetChild(4).gameObject;
        Instantiate(choice, State1.GetComponent<Transform>().position, new Quaternion(0, 0, 0, 0));
        yield return new WaitForSeconds(2);
        GameObject State2 = States.GetComponent<Transform>().GetChild(8).gameObject;
        Instantiate(choice, State2.GetComponent<Transform>().position, new Quaternion(0, 0, 0, 0));
        yield return new WaitForSeconds(2);
        GameObject State3 = States.GetComponent<Transform>().GetChild(12).gameObject;
        Instantiate(choice, State3.GetComponent<Transform>().position, new Quaternion(0, 0, 0, 0));
        yield return new WaitForSeconds(2);
        GameObject State4 = States.GetComponent<Transform>().GetChild(13).gameObject;
        Instantiate(choice, State4.GetComponent<Transform>().position, new Quaternion(0, 0, 0, 0));
        yield return new WaitForSeconds(2);
        GameObject State5 = States.GetComponent<Transform>().GetChild(14).gameObject;
        Instantiate(choice, State5.GetComponent<Transform>().position, new Quaternion(0, 0, 0, 0));
        yield return new WaitForSeconds(2);
        GameObject State6 = States.GetComponent<Transform>().GetChild(15).gameObject;
        Instantiate(choice, State6.GetComponent<Transform>().position, new Quaternion(0, 0, 0, 0));

    }
    // Start is called before the first frame update
    void Start()
    {

        StartCoroutine(game());

    }

    
    //string[] ans = getChoices(State);
    //Debug.Log("State: " + getChoices(State));
    //List<string> choices = getChoices(State);
    //foreach (string choice in choices)
    //{
    //    Debug.Log("State: "+ choice);
    //}

    // Update is called once per frame
    void Update()
    {
        
    }
}
