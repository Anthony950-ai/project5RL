using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Trainer : MonoBehaviour
{
    //private Dictionary<string, Dictionary<string, double>> Q;

    //private double learning_rate = 0.1;
    //private double discount_factor = 0.9;
    //private double epsilon = 0.1;

    //public QLearning()
    //{
    //    Q = new Dictionary<string, Dictionary<string, double>>();
    //}

    //public void UpdateQ(string state, string action, double reward, string next_state)
    //{
    //    if (!Q.ContainsKey(state))
    //    {
    //        Q[state] = new Dictionary<string, double>();
    //    }

    //    if (!Q[state].ContainsKey(action))
    //    {
    //        Q[state][action] = 0.0;
    //    }

    //    double current_q = Q[state][action];
    //    double max_future_q = GetMaxQ(next_state);

    //    double new_q = current_q + learning_rate * (reward + discount_factor * max_future_q - current_q);
    //    Q[state][action] = new_q;
    //}

    //public string GetAction(string state)
    //{
    //    if (!Q.ContainsKey(state))
    //    {
    //        Q[state] = new Dictionary<string, double>();
    //    }

    //    string[] actions = new string[] { "up", "down", "left", "right" };

    //    if (UnityEngine.Random.value < epsilon)
    //    {
    //        // Choose a random action
    //        return actions[UnityEngine.Random.Range(0, actions.Length)];
    //    }
    //    else
    //    {
    //        // Choose the action with the highest Q-value
    //        double max_q = double.MinValue;
    //        string best_action = "";

    //        foreach (string action in actions)
    //        {
    //            if (!Q[state].ContainsKey(action))
    //            {
    //                Q[state][action] = 0.0;
    //            }

    //            double q = Q[state][action];

    //            if (q > max_q)
    //            {
    //                max_q = q;
    //                best_action = action;
    //            }
    //        }

    //        return best_action;
    //    }
    //}

    //private double GetMaxQ(string state)
    //{
    //    if (!Q.ContainsKey(state))
    //    {
    //        Q[state] = new Dictionary<string, double>();
    //    }

    //    double max_q = double.MinValue;

    //    foreach (string action in Q[state].Keys)
    //    {
    //        double q = Q[state][action];

    //        if (q > max_q)
    //        {
    //            max_q = q;
    //        }
    //    }

    //    return max_q;
    //}



    //void resetEnv()
    //{
    //    GameObject[] objects = GameObject.FindObjectsOfType<GameObject>();
    //    foreach (GameObject obj in objects)
    //    {
    //        if (obj.name.Contains("Clone"))
    //        {
    //            // Do something with the GameObject here
    //            Destroy(obj);
    //        }
    //    }
    //}

    // Update is called once per frame
    void Update()
    {
        
    }
}
